var e=`{{identical|Settings}}`,t={"@metadata":{authors:[`BryanDavis`,`Liuxinyu970226`,`Mklehr`,`Nemo bis`,`Robby`,`Shirayuki`,`Siebrand`,`Tim.krieger`]},"admin_plugins.available_install.value":`{{Identical|Install}}`,"admin_plugins.description":`{{Identical|Description}}`,"admin_plugins.installed_uninstall.value":`{{Identical|Uninstall}}`,"admin_plugins.last-update":`{{Identical|Last update}}`,"admin_plugins.name":`{{Identical|Name}}`,"admin_plugins.tag_deprecated":`{{Identical|Deprecated}}`,"admin_plugins.version":`{{Identical|Version}}`,admin_settings:e,"index.newPad":`Used as button text.
A pad, in the context of Etherpad, is a notepad, something to write on.`,"index.createOpenPad":`label for an input field that allows the user to choose a custom name for his new pad. In case the pad already exists the user will be redirected to its url.`,"pad.toolbar.bold.title":`Used as tooltip of button`,"pad.toolbar.italic.title":`Used as tooltip of button`,"pad.toolbar.underline.title":`Used as tooltip of button`,"pad.toolbar.strikethrough.title":`Used as tooltip of button.
{{Identical|Strikethrough}}`,"pad.toolbar.ol.title":`Used as tooltip for button`,"pad.toolbar.ul.title":`Used as tooltip for button`,"pad.toolbar.indent.title":`Used as tooltip of button.

"TAB" refers to "Tab key".

See also:
* {{msg-etherpadlite|Pad.toolbar.unindent.title}}
{{Identical|Indent}}`,"pad.toolbar.unindent.title":`Used as tooltip of button.

"TAB" refers to "Tab key".

See also:
* {{msg-etherpadlite|Pad.toolbar.indent.title}}`,"pad.toolbar.undo.title":`Used as tooltip of button`,"pad.toolbar.redo.title":`Used as tooltip of button
{{Identical|Redo}}`,"pad.toolbar.clearAuthorship.title":`Used as tooltip of button`,"pad.toolbar.import_export.title":`Used as tooltip of button`,"pad.toolbar.timeslider.title":`The timeslider is a separate "page" that allows you to browse through the history of your pad's contents`,"pad.toolbar.savedRevision.title":`Used as tooltip for button.`,"pad.toolbar.settings.title":`settings that determine how the pad content is displayed
{{Identical|Settings}}`,"pad.toolbar.embed.title":`Used as tooltip for button`,"pad.toolbar.showusers.title":`Used as tooltip for button`,"pad.colorpicker.save":`Used as button text in the "Color picker" window.

See also:
* {{msg-etherpadlite|Pad.colorpicker.cancel}}
{{Identical|Save}}`,"pad.colorpicker.cancel":`Used as button text in the "Color picker" window.

See also:
* {{msg-etherpadlite|Pad.colorpicker.save}}
{{Identical|Cancel}}`,"pad.loading":`Used to indicate the pad is being loaded.
{{Identical|Loading}}`,"pad.permissionDenied":`Used as error message.`,"pad.settings.padSettings":`Used as heading of settings window`,"pad.settings.myView":`Section heading for a users personal settings, meaning changes to the settings in this section will only affect the current view (this browser window) of the pad.`,"pad.settings.stickychat":`Used as checkbox label`,"pad.settings.colorcheck":`Used as checkbox label`,"pad.settings.linenocheck":`Used as checkbox label`,"pad.settings.rtlcheck":`Used as label for checkbox for RTL (right-to-left) languages`,"pad.settings.fontType":`Used as label for the "Font type" select box which has the following options:
* {{msg-etherpadlite|Pad.settings.fontType.normal}}
* {{msg-etherpadlite|Pad.settings.fontType.monospaced}}`,"pad.settings.fontType.normal":`Used as an option in the "Font type" select box which is labeled {{msg-etherpadlite|Pad.settings.fontType}}.
{{Identical|Normal}}`,"pad.settings.language":`This is a label for a select list of languages.
{{Identical|Language}}`,"pad.settings.about":`{{Identical|About}}`,"pad.importExport.import_export":`Used as HTML <code><nowiki><h1></nowiki></code> heading of window.

Followed by the child heading {{msg-etherpadlite|Pad.importExport.import}}.`,"pad.importExport.import":`Used as HTML <code><nowiki><h2></nowiki></code> heading.

Preceded by the parent heading {{msg-etherpadlite|Pad.importExport.import_export}}.`,"pad.importExport.importSuccessful":`Used as success message to indicate that the pad has been imported successfully.
{{Identical|Successful}}`,"pad.importExport.export":`Used as HTML <code><nowiki><h2></nowiki></code> heading.

Followed by the following link texts:
* {{msg-etherpadlite|Pad.importExport.exporthtml}}
* {{msg-etherpadlite|Pad.importExport.exportplain}}
* {{msg-etherpadlite|Pad.importExport.exportword}}
* {{msg-etherpadlite|Pad.importExport.exportpdf}}
* {{msg-etherpadlite|Pad.importExport.exportopen}}
* {{msg-etherpadlite|Pad.importExport.exportdokuwiki}}`,"pad.importExport.exportetherpad":`{{Identical|Etherpad}}`,"pad.importExport.exporthtml":`Used as link text, preceded by {{msg-etherpadlite|Pad.importExport.export}}.
{{Related|Pad.importExport.export}}
{{Identical|HTML}}`,"pad.importExport.exportplain":`Used as link text, preceded by {{msg-etherpadlite|Pad.importExport.export}}.
{{Related|Pad.importExport.export}}
{{Identical|Plain text}}`,"pad.importExport.exportword":`Used as link text, preceded by {{msg-etherpadlite|Pad.importExport.export}}.
{{Related|Pad.importExport.export}}`,"pad.importExport.exportpdf":`Used as link text, preceded by {{msg-etherpadlite|Pad.importExport.export}}.
{{Related|Pad.importExport.export}}`,"pad.importExport.exportopen":`Used as link text, preceded by {{msg-etherpadlite|Pad.importExport.export}}.
{{Related|Pad.importExport.export}}`,"pad.modals.connected":`Used as HTML <code><nowiki><h2></nowiki></code> heading to indicate the status.

See also:
* {{msg-etherpadlite|Pad.modals.reconnecting}}
{{Identical|Connected}}`,"pad.modals.reconnecting":`Used as HTML <code><nowiki><h2></nowiki></code> heading to indicate the status.

See also:
* {{msg-etherpadlite|Pad.modals.connected}}`,"pad.modals.forcereconnect":`Label of a button that will make the browser reconnect to the synchronization server.`,"pad.modals.cancel":`{{Identical|Cancel}}`,"pad.modals.userdup":`Used as HTML <code><nowiki><h1></nowiki></code> heading to indicate that the pad is opened in another window on this computer.

Followed by the following messages:
* {{msg-etherpadlite|Pad.modals.userdup.explanation}} - <code><nowiki><h2></nowiki></code> heading
* {{msg-etherpadlite|Pad.modals.userdup.advice}}`,"pad.modals.userdup.explanation":`Used as HTML <code><nowiki><h2></nowiki></code> heading.

Preceded by the parent heading {{msg-etherpadlite|Pad.modals.userdup}}.

Followed by the message {{msg-etherpadlite|Pad.modals.userdup.advice}}.`,"pad.modals.userdup.advice":`Preceded by the following headings:
* {{msg-etherpadlite|Pad.modals.userdup}}
* {{msg-etherpadlite|Pad.modals.userdup.explanation}}`,"pad.modals.unauth":`Used as HTML <code><nowiki><h1></nowiki></code> heading to indicate that the user is not authorized.

Followed by the explanation {{msg-etherpadlite|Pad.modals.unauth.explanation}}.
{{Identical|Not authorized}}`,"pad.modals.unauth.explanation":`Used to indicate that the user is not authorized.

Preceded by the heading {{msg-etherpadlite|Pad.modals.unauth}}.`,"pad.modals.looping.explanation":`Used as HTML <code><nowiki><h2></nowiki></code> heading.

Preceded by the parent heading {{msg-etherpadlite|Pad.modals.looping}}.

Followed by the message {{msg-etherpadlite|Pad.modals.looping.cause}}.`,"pad.modals.looping.cause":`Preceded by the following messages:
* {{msg-etherpadlite|Pad.modals.looping}}
* {{msg-etherpadlite|Pad.modals.looping.explanation}}`,"pad.modals.initsocketfail":`Used as HTML <code><nowiki><h1></nowiki></code> heading.`,"pad.modals.initsocketfail.explanation":`Used as HTML <code><nowiki><h2></nowiki></code> heading.`,"pad.modals.initsocketfail.cause":`Preceded by the following headings:
* {{msg-etherpadlite|Pad.modals.initsocketfail}}
* {{msg-etherpadlite|Pad.modals.initsocketfail.explanation}}`,"pad.modals.slowcommit.explanation":`Used as HTML <code><nowiki><h2></nowiki></code> heading.`,"pad.modals.slowcommit.cause":`Preceded by the following headings:
* {{msg-etherpadlite|Pad.modals.slowcommit}}
* {{msg-etherpadlite|Pad.modals.slowcommit.explanation}}
Followed by the Submit button which is labeled {{msg-etherpadlite|Pad.modals.forcereconnect}}.`,"pad.modals.deleted":`Used as HTML <code><nowiki><h1></nowiki></code> heading.
{{Identical|Deleted}}`,"pad.modals.deleted.explanation":`Preceded by the heading {{msg-etherpadlite|Pad.modals.deleted}}.`,"pad.modals.disconnected":`Used as HTML <code><nowiki><h1></nowiki></code> heading.`,"pad.modals.disconnected.explanation":`Used as HTML <code><nowiki><h2></nowiki></code> heading.`,"pad.modals.disconnected.cause":`Preceded by the following headings:
* {{msg-etherpadlite|Pad.modals.disconnected}}
* {{msg-etherpadlite|Pad.modals.disconnected.explanation}}
Followed by the Submit button which is labeled {{msg-etherpadlite|Pad.modals.forcereconnect}}.`,"pad.share":`Used as heading of window`,"pad.share.readonly":`Used as checkbox label`,"pad.share.link":`Used as label for a field providing URL of the pad.
{{Identical|Link}}`,"pad.share.emebdcode":`Label for a field providing code that allows you to embed the pad into your website.`,"pad.chat":`Used as button text and as title of Chat window.
{{Identical|Chat}}`,"pad.chat.title":`Used as tooltip for the Chat button`,"pad.chat.loadmessages":`chat messages`,"pad.chat.stick.title":`Tooltip for the stick chat button`,"pad.chat.writeMessage.placeholder":`Placeholder for the chat input`,"timeslider.pageTitle":`{{doc-important|Please leave <code><nowiki>{{appTitle}}</nowiki></code> parameter untouched. It will be replaced by app title.}}
Inserted into HTML title tag.`,"timeslider.toolbar.returnbutton":`Used as link title`,"timeslider.toolbar.authors":`A list of Authors follows after the colon.
{{Identical|Author}}`,"timeslider.toolbar.authorsList":`Displayed when there are no authors of the currently viewed revision.`,"timeslider.toolbar.exportlink.title":`Used in Timeslider view.

Used as tooltip for the "Export" button which enables to export the current pad as HTML, plain text, or DokuWiki.

If the button is clicked, the following messages appear:
* {{msg-etherpadlite|Timeslider.exportCurrent}}
* {{msg-etherpadlite|Pad.importExport.exporthtml}}
* {{msg-etherpadlite|Pad.importExport.exportplain}}
* {{msg-etherpadlite|Pad.importExport.exportdokuwiki}}
{{Identical|Export}}`,"timeslider.exportCurrent":`Used as label in the Timeslider view.

Followed by the following link texts (which are used to export the current pad):
* {{msg-etherpadlite|Pad.importExport.exporthtml}}
* {{msg-etherpadlite|Pad.importExport.exportplain}}
* {{msg-etherpadlite|Pad.importExport.exportword}}
* {{msg-etherpadlite|Pad.importExport.exportpdf}}
* {{msg-etherpadlite|Pad.importExport.exportopen}}
* {{msg-etherpadlite|Pad.importExport.exportdokuwiki}}`,"timeslider.version":`{{doc-important|Please leave <nowiki>{{version}}</nowiki> parameter untouched. It will be replaced with the version number}}`,"timeslider.saved":`{{doc-important|Do not translate <code><nowiki>{{month}}</nowiki></code>, <code><nowiki>{{day}}</nowiki></code> and <code><nowiki>{{year}}</nowiki></code> parameters. These will be replaced.}}
Parameters:
* <nowiki>{{month}}</nowiki> - month name such as {{msg-etherpadlite|Timeslider.month.january}}, {{msg-etherpadlite|Timeslider.month.february}} and so on
* <nowiki>{{day}}</nowiki> - day of the month (01-31)
* <nowiki>{{year}}</nowiki> - year in 4 digit format`,"timeslider.dateformat":`{{doc-important|Do not translate <code><nowiki>month</nowiki></code>, <code><nowiki>day</nowiki></code>, <code><nowiki>year</nowiki></code>, <code><nowiki>hours</nowiki></code>, <code><nowiki>minutes</nowiki></code> and <code><nowiki>seconds</nowiki></code> parameters. These will be replaced.}}
* <nowiki>{{month}}</nowiki> - a month number (01-12), NOT {{msg-etherpadlite|Timeslider.month.january}} etc.
* <nowiki>{{day}}</nowiki> - day of the month (01-31)
* <nowiki>{{year}}</nowiki> - year in 4 digit format
* <nowiki>{{hours}}</nowiki> - hours (00-23)
* <nowiki>{{minutes}}</nowiki> - minutes (00-59)
* <nowiki>{{seconds}}</nowiki> - seconds (00-59)`,"timeslider.month.january":`Example usage: <samp>Saved on August 26, 2014</samp>. This message is substituted for:
* {{msg-etherpadlite|Timeslider.saved|notext=1}}
* {{msg-etherpadlite|Timeslider.dateformat|notext=1}}
{{Identical|January}}`,"timeslider.month.february":`Example usage: <samp>Saved on August 26, 2014</samp>.
{{Identical|February}}`,"timeslider.month.march":`Example usage: <samp>Saved on August 26, 2014</samp>.
{{Identical|March}}`,"timeslider.month.april":`Example usage: <samp>Saved on August 26, 2014</samp>.
{{Identical|April}}`,"timeslider.month.may":`Example usage: <samp>Saved on August 26, 2014</samp>.
{{Identical|May}}`,"timeslider.month.june":`Example usage: <samp>Saved on August 26, 2014</samp>.
{{Identical|June}}`,"timeslider.month.july":`Example usage: <samp>Saved on August 26, 2014</samp>.
{{Identical|July}}`,"timeslider.month.august":`Example usage: <samp>Saved on August 26, 2014</samp>.
{{Identical|August}}`,"timeslider.month.september":`Example usage: <samp>Saved on August 26, 2014</samp>.
{{Identical|September}}`,"timeslider.month.october":`Example usage: <samp>Saved on August 26, 2014</samp>.
{{Identical|October}}`,"timeslider.month.november":`Example usage: <samp>Saved on August 26, 2014</samp>.
{{Identical|November}}`,"timeslider.month.december":`Example usage: <samp>Saved on August 26, 2014</samp>.
{{Identical|December}}`,"timeslider.unnamedauthors":`See also:
* {{msg-etherpadlite|Timeslider.unnamedauthor}}`,"pad.savedrevs.marked":`more like bookmarked, or tagged/starred`,"pad.userlist.entername":`Used as placeholder for the "Name" input box in the upper right corner of the screen. It's important to keep it short: Long sentences aren't displayed.`,"pad.userlist.unnamed":`Displayed, if a user has not set a nick yet`,"pad.editbar.clearcolors":`Used as confirmation message (JavaScript <code>confirm()</code> function).

This message means "Are you sure you want to clear authorship colors on entire document? This cannot be undone".`,"pad.impexp.importbutton":`Used as label for the Submit button.`,"pad.impexp.importing":`Used to indicate that the file is being imported.
{{Identical|Importing}}`,"pad.impexp.confirmimport":`Used as confirmation message (JavaScript <code>confirm()</code> function).`,"pad.impexp.convertFailed":`Used as error message when importing a file.`,"pad.impexp.uploadFailed":`Used as error message when uploading a file.

This message means "The upload has been failed. Please try again.".`,"pad.impexp.importfailed":`Used as error message.

This message means "The import has been failed".

Followed by any one of the following messages:
* {{msg-etherpadlite|Pad.impexp.convertFailed}}
* {{msg-etherpadlite|Pad.impexp.uploadFailed}}
* {{msg-etherpadlite|Pad.impexp.copypaste}}`,"pad.impexp.copypaste":`Displayed in case the import failed`,"pad.impexp.exportdisabled":`{{doc-important|Please leave <nowiki>{{type}}</nowiki> parameter untouched. It will be replaced}}`};export{e as admin_settings,t as default};