export type SocketAcknowledge = {

}
