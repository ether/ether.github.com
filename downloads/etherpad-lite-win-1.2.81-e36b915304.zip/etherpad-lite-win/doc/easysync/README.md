# About this folder
We put all documentations we found about the old Etherpad together in this folder. Most of this is still valid for Etherpad Lite