@include documentation
@include stats
@include localization
@include custom_static
@include api/api
@include plugins
@include database
