function customStart()
{
  $('#pad_title').show();
}
