@include documentation
@include localization
@include custom_static
@include api/api
@include plugins
@include database
