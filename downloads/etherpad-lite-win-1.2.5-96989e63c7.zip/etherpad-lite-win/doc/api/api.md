@include embed_parameters
@include http_api
@include hooks_overview
@include hooks_client-side
@include hooks_server-side
@include editorInfo
@include changeset_library
@include pluginfw