@include documentation
@include stats
@include localization
@include skins
@include api/api
@include plugins
@include database
