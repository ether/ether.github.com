#!/bin/bash
#nano src/package.json

git checkout -b "release/$VERSION" develop
#nano src/CHANGELOG.md
#git push -u origin "release/$VERSION"

#github: open PR
#github: open release tag

bin/buildForWindows.sh
mv zipfile ../ether.github.com/etherpad-lite-win-$VERSION-sha.zip

make docs
mv out/doc ../ether.github.com/doc/$VERSION/

#ether.github.com: adjust links

# git checkout develop
#Switched to branch 'develop'
# git merge --no-ff release-1.2
#Merge made by recursive.
#(Summary of changes)

